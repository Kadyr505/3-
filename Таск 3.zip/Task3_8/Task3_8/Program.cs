﻿using System;
using System.Drawing;

namespace Task3_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Point a = new Point(0, 0);
            Point b = new Point(10, 0);
            Point c = new Point(10, 10);
            Point d = new Point(0, 10);
            Square square = new Square(a, b, c, d, Color.Red);
            square.Stretch(1.5);
            square.Turn(true);
            square.Color = Color.Aqua;
        }
    }
}