﻿using System.Drawing;

namespace Task3_8
{
    public class Square
    {
        private Line[] lines = new Line[4];
        private Color color;

        public Square(Point point1, Point point2, Point point3, Point point4, Color color)
        {
            lines[0] = new Line(point1, point2);
            lines[1] = new Line(point2, point3);
            lines[2] = new Line(point3, point4);
            lines[3] = new Line(point4, point1);
            this.color = color;
        }

        public Square(Line line1, Line line2, Line line3, Line line4, Color color)
        {
            lines[0] = line1;
            lines[1] = line2;
            lines[2] = line3;
            lines[3] = line4;
            this.color = color;
        }

        public Line[] Lines
        {
            get => lines;
            set => lines = value;
        }

        public Color Color
        {
            get => color;
            set => color = value;
        }

        public void Stretch(double factor)
        {
            foreach (Line line in lines)
            {
                line.Stretch(factor);
            }
        }

        public void Turn(bool right)
        {
            if (right)
            {
                Line tmpLine = lines[0];
                lines[0] = lines[3];
                lines[3] = lines[2];
                lines[2] = lines[1];
                lines[1] = tmpLine;
            }
            else
            {
                Line tmpLine = lines[0];
                lines[0] = lines[1];
                lines[1] = lines[2];
                lines[2] = lines[3];
                lines[3] = tmpLine;
            }
        }
    }
}