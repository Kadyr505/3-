﻿namespace Task3_8
{
    public class Line
    {
        private Point a;
        private Point b;

        public Line(Point a, Point b)
        {
            this.a = a;
            this.b = b;
        }

        public Point A
        {
            get => a;
            set => a = value;
        }

        public Point B
        {
            get => b;
            set => b = value;
        }

        public void Stretch(double factor)
        {
            double centerX = (a.X - b.X) / 2;
            double centerY = (a.Y - b.Y) / 2;
            a.X = (int) ((a.X - centerX) * factor - centerX);
            a.Y = (int) ((a.Y - centerY) * factor - centerY);
            b.X = (int) ((b.X - centerX) * factor - centerX);
            b.Y = (int) ((b.Y - centerY) * factor - centerY);
        }
    }
}